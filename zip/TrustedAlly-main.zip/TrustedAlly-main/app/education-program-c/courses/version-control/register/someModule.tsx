// someModule.tsx
export const brevity = true
export const it = true
export const is = true
export const correct = true
export const and = true

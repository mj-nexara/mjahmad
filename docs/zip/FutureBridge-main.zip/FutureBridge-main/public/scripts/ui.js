// Handle UI interactions
document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("donate-btn").addEventListener("click", () => {
        alert("Thank you for contributing!");
    });
});
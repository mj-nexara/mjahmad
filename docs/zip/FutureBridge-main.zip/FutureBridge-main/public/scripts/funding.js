// Load funding data dynamically
fetch("data/funding.json")
    .then(response => response.json())
    .then(data => {
        console.log("Funding Data:", data);
    })
    .catch(error => console.error("Error fetching data:", error));
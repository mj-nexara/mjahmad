// Connect with backend API
async function contribute(name, amount) {
    const response = await fetch("http://localhost:3000/contribute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, amount })
    });

    const result = await response.json();
    console.log(result);
}
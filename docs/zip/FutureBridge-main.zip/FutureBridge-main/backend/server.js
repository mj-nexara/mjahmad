const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;

let funding = {
    current_funds: 0,
    goal: 2000,
    contributors: []
};

// API to get funding data
app.get('/funding', (req, res) => {
    res.json(funding);
});

// API to contribute funds
app.post('/contribute', (req, res) => {
    const { name, amount } = req.body;
    if (!name || !amount) {
        return res.status(400).json({ error: "Name and amount are required!" });
    }
    
    funding.current_funds += amount;
    funding.contributors.push({ name, amount });
    
    res.json({ message: "Thank you for your contribution!", funding });
});

app.listen(PORT, () => {
    console.log(`Funding API running on http://localhost:${PORT}`);
});
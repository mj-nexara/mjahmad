document.addEventListener("DOMContentLoaded", () => {
    fetch("data/funding.json")
        .then(response => response.json())
        .then(data => {
            document.getElementById("current-funds").innerText = `Current Funds: $${data.funding_campaign.current_funds}`;
        })
        .catch(error => console.error("Error fetching funding data:", error));
    
    document.getElementById("funding-form").addEventListener("submit", (event) => {
        event.preventDefault();
        const name = document.getElementById("name").value;
        const amount = parseFloat(document.getElementById("amount").value);
        
        fetch("http://localhost:3000/contribute", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, amount })
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            location.reload();
        })
        .catch(error => console.error("Error contributing:", error));
    });
});